#!/bin/bash

rm *.zip
zip spotify.zip -r *
#pip3 install -r requirements.txt -t ./libs
aws s3 rm s3://kihong-spotify-lambda/spotify.zip
aws s3 cp ./spotify.zip s3://kihong-spotify-lambda/spotify.zip
aws lambda update-function-code --function-name spotify-lambda --s3-bucket kihong-spotify-lambda --s3-key spotify.zip
