
client_id = "1c3ed4de0a6740869047a1e2b1d32f7f"
client_secret = "cb61a7f182224fddb6df6cc6aa9c3f3e"

host = "trivago.c4cyhkpwwxor.ap-northeast-2.rds.amazonaws.com"
port = 3306
user = "admin"
password = "rlghd17641"
database = "spotify"


facebook_token = "EAAFJhpubq0gBADEPBOv3hMVZCDj7x49jDLLbDVfLeA8RLbsvy0cGQMGyoJcXQJlXNXono4V36qEcZAiHw6Flpi9Kf9vk1ZAkY1wNdWCziaPd9pxvYrFLcxEtgVsQyLmj02KeLm9shuR3Qx2ZBxI6e4xvoHsZA9xv0N2ZASJqCZBuwZDZD"
